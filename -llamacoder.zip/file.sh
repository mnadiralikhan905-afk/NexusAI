   npx create-next-app@latest nexus-ai-assistant
   cd nexus-ai-assistant
   # Copy all files from above
   npm install framer-motion lucide-react recharts
   npm run build
   ```
3. **Vercel mein import karein:**
   - Vercel dashboard mein "New Project" click karein
   - GitHub repository select karein
   - Deploy button dabayein
4. **Link mil jayega:** `https://your-app.vercel.app`

### **Option 2: Netlify**

1. **Netlify account:** https://netlify.com
2. **Drag & Drop deploy:**
   - `npm run build` run karein
   - `out` folder ko Netlify mein drag karein
3. **Link mil jayega**

### **Option 3: GitHub Pages**
