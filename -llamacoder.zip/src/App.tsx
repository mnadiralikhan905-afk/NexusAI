import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Sidebar from "./components/Sidebar";
import ChatView from "./components/ChatView";
import ImageGenerator from "./components/ImageGenerator";
import VoiceAssistant from "./components/VoiceAssistant";
import DocumentAI from "./components/DocumentAI";
import ProductivitySuite from "./components/ProductivitySuite";
import AnalyticsDashboard from "./components/AnalyticsDashboard";
import Settings from "./components/Settings";

export type ViewType = "chat" | "image" | "voice" | "document" | "productivity" | "analytics" | "settings";

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>("chat");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const renderView = () => {
    switch (currentView) {
      case "chat":
        return <ChatView />;
      case "image":
        return <ImageGenerator />;
      case "voice":
        return <VoiceAssistant />;
      case "document":
        return <DocumentAI />;
      case "productivity":
        return <ProductivitySuite />;
      case "analytics":
        return <AnalyticsDashboard />;
      case "settings":
        return <Settings />;
      default:
        return <ChatView />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 text-white overflow-hidden">
      <Sidebar
        currentView={currentView}
        setCurrentView={setCurrentView}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
      />
      
      <main className="flex-1 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}