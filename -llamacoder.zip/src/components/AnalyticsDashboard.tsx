import { motion } from "framer-motion";
import { BarChart3, TrendingUp, Clock, Zap, Star, ArrowUp } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";

const usageData = [
  { name: "Mon", chats: 45, images: 12, voice: 8 },
  { name: "Tue", chats: 52, images: 18, voice: 15 },
  { name: "Wed", chats: 38, images: 14, voice: 10 },
  { name: "Thu", chats: 65, images: 22, voice: 18 },
  { name: "Fri", chats: 48, images: 16, voice: 12 },
  { name: "Sat", chats: 72, images: 28, voice: 22 },
  { name: "Sun", chats: 55, images: 20, voice: 16 },
];

const productivityData = [
  { name: "Week 1", score: 72 },
  { name: "Week 2", score: 78 },
  { name: "Week 3", score: 85 },
  { name: "Week 4", score: 92 },
];

const featureUsage = [
  { name: "AI Chat", usage: 45, color: "bg-violet-500" },
  { name: "Image Gen", usage: 28, color: "bg-pink-500" },
  { name: "Voice AI", usage: 15, color: "bg-cyan-500" },
  { name: "Documents", usage: 12, color: "bg-amber-500" },
];

export default function AnalyticsDashboard() {
  return (
    <div className="h-full overflow-y-auto bg-slate-950">
      <div className="max-w-6xl mx-auto p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">Analytics Dashboard</h2>
          </div>
          <p className="text-slate-400">Track your AI usage and productivity metrics</p>
        </motion.div>

        {/* Key Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6"
        >
          {[
            { label: "Total Interactions", value: "2,847", change: "+12%", icon: Zap, color: "from-violet-500 to-purple-600" },
            { label: "Time Saved", value: "48h", change: "+8h", icon: Clock, color: "from-emerald-500 to-green-600" },
            { label: "Tasks Completed", value: "156", change: "+23%", icon: Star, color: "from-amber-500 to-orange-600" },
            { label: "Productivity Score", value: "92", change: "+5", icon: TrendingUp, color: "from-blue-500 to-cyan-600" },
          ].map((metric, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-slate-900 rounded-xl p-4 border border-slate-800"
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${metric.color} flex items-center justify-center`}>
                  <metric.icon className="w-5 h-5 text-white" />
                </div>
                <span className="flex items-center gap-1 text-xs font-medium text-emerald-400">
                  <ArrowUp className="w-3 h-3" />
                  {metric.change}
                </span>
              </div>
              <p className="text-2xl font-bold text-white">{metric.value}</p>
              <p className="text-xs text-slate-500">{metric.label}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          {/* Usage Chart */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
          >
            <h3 className="font-semibold text-white mb-4">AI Usage Over Time</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={usageData}>
                  <defs>
                    <linearGradient id="colorChats" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorImages" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ec4899" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#ec4899" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }}
                    labelStyle={{ color: '#fff' }}
                  />
                  <Area type="monotone" dataKey="chats" stroke="#8b5cf6" fill="url(#colorChats)" strokeWidth={2} />
                  <Area type="monotone" dataKey="images" stroke="#ec4899" fill="url(#colorImages)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-center gap-6 mt-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-violet-500" />
                <span className="text-xs text-slate-400">Chats</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-pink-500" />
                <span className="text-xs text-slate-400">Images</span>
              </div>
            </div>
          </motion.div>

          {/* Productivity Score */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
          >
            <h3 className="font-semibold text-white mb-4">Productivity Score</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={productivityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }}
                    labelStyle={{ color: '#fff' }}
                  />
                  <Line type="monotone" dataKey="score" stroke="#10b981" strokeWidth={3} dot={{ fill: '#10b981', strokeWidth: 2 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        </div>

        {/* Feature Usage */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
        >
          <h3 className="font-semibold text-white mb-6">Feature Usage Distribution</h3>
          <div className="space-y-4">
            {featureUsage.map((feature, index) => (
              <div key={index} className="flex items-center gap-4">
                <span className="w-24 text-sm text-slate-400">{feature.name}</span>
                <div className="flex-1 h-3 bg-slate-800 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${feature.usage}%` }}
                    transition={{ duration: 1, delay: index * 0.1 }}
                    className={`h-full ${feature.color} rounded-full`}
                  />
                </div>
                <span className="text-sm font-medium text-white">{feature.usage}%</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}