import { useState } from "react";
import { motion } from "framer-motion";
import { FileText, Upload, File, Trash2, Download, Search, MessageSquare, Globe, FileCheck } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";

const sampleDocuments = [
  { id: 1, name: "Q4 Financial Report.pdf", size: "2.4 MB", type: "pdf", date: "2024-01-15" },
  { id: 2, name: "Marketing Strategy.docx", size: "1.2 MB", type: "docx", date: "2024-01-14" },
  { id: 3, name: "Sales Data.xlsx", size: "856 KB", type: "xlsx", date: "2024-01-13" },
];

export default function DocumentAI() {
  const [selectedDoc, setSelectedDoc] = useState<number | null>(null);
  const [query, setQuery] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);

  const handleAnalyze = () => {
    if (!query.trim()) return;
    setIsAnalyzing(true);
    setTimeout(() => {
      setAnalysisResult(`Based on the document analysis:

**Key Findings:**
• Revenue increased by 23% compared to previous quarter
• Customer acquisition cost decreased by 15%
• Net promoter score improved from 42 to 58

**Summary:**
The document indicates strong quarterly performance with significant improvements across key metrics. The marketing strategies implemented in Q3 have shown positive results.

**Recommendations:**
1. Continue current marketing approach
2. Invest in customer success programs
3. Expand into new market segments`);
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="h-full overflow-y-auto bg-slate-950">
      <div className="max-w-6xl mx-auto p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">Document AI</h2>
          </div>
          <p className="text-slate-400">Upload, analyze, and extract insights from your documents</p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Panel - Document List */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            {/* Upload Area */}
            <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 border-dashed">
              <div className="text-center">
                <div className="w-12 h-12 rounded-xl bg-amber-500/20 flex items-center justify-center mx-auto mb-3">
                  <Upload className="w-6 h-6 text-amber-400" />
                </div>
                <p className="text-sm text-slate-300 mb-2">Drag & drop files here</p>
                <p className="text-xs text-slate-500 mb-4">PDF, DOCX, XLSX, PPTX supported</p>
                <Button className="bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 rounded-xl">
                  <Upload className="w-4 h-4 mr-2" />
                  Browse Files
                </Button>
              </div>
            </div>

            {/* Document List */}
            <div className="bg-slate-900 rounded-2xl p-4 border border-slate-800">
              <h3 className="font-medium text-white mb-3 px-2">Your Documents</h3>
              <div className="space-y-2">
                {sampleDocuments.map((doc) => (
                  <button
                    key={doc.id}
                    onClick={() => setSelectedDoc(doc.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${
                      selectedDoc === doc.id
                        ? "bg-amber-500/20 border border-amber-500/50"
                        : "bg-slate-800 hover:bg-slate-700"
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      doc.type === "pdf" ? "bg-red-500/20 text-red-400" :
                      doc.type === "docx" ? "bg-blue-500/20 text-blue-400" :
                      "bg-green-500/20 text-green-400"
                    }`}>
                      <File className="w-5 h-5" />
                    </div>
                    <div className="text-left flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">{doc.name}</p>
                      <p className="text-xs text-slate-500">{doc.size} • {doc.date}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Right Panel - Analysis */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-2 space-y-4"
          >
            {/* Quick Actions */}
            <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800">
              <h3 className="font-medium text-white mb-4">Quick Actions</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { icon: FileCheck, label: "Summarize", color: "from-amber-500 to-orange-500" },
                  { icon: Globe, label: "Translate", color: "from-blue-500 to-cyan-500" },
                  { icon: Search, label: "Extract Data", color: "from-purple-500 to-violet-500" },
                  { icon: MessageSquare, label: "Ask Questions", color: "from-emerald-500 to-green-500" },
                ].map((action) => (
                  <button
                    key={action.label}
                    className="flex flex-col items-center gap-2 p-4 rounded-xl bg-slate-800 hover:bg-slate-700 transition-all group"
                  >
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${action.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <action.icon className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-sm text-slate-300">{action.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Query Input */}
            <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800">
              <label className="block text-sm font-medium text-slate-300 mb-3">
                Ask a question about your document
              </label>
              <Textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="What are the key findings in this report?"
                className="min-h-24 bg-slate-800 border-slate-700 text-white placeholder-slate-500 focus:border-amber-500 resize-none"
              />
              <div className="flex items-center justify-between mt-4">
                <p className="text-xs text-slate-500">
                  {selectedDoc ? "Document selected" : "Please select a document first"}
                </p>
                <Button
                  onClick={handleAnalyze}
                  disabled={!selectedDoc || !query.trim() || isAnalyzing}
                  className="px-6 py-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white rounded-xl disabled:opacity-50"
                >
                  {isAnalyzing ? "Analyzing..." : "Analyze"}
                </Button>
              </div>
            </div>

            {/* Results */}
            {analysisResult && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-medium text-white">Analysis Results</h3>
                  <div className="flex items-center gap-2">
                    <Button className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg">
                      <Download className="w-4 h-4 text-slate-400" />
                    </Button>
                    <Button className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg">
                      <Trash2 className="w-4 h-4 text-slate-400" />
                    </Button>
                  </div>
                </div>
                <div className="prose prose-invert max-w-none">
                  <p className="whitespace-pre-wrap text-slate-300">{analysisResult}</p>
                </div>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}