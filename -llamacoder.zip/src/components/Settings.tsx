import { useState } from "react";
import { motion } from "framer-motion";
import { Settings as SettingsIcon, User, Bell, Shield, Palette, Globe, CreditCard, LogOut, ChevronRight, Moon, Sun, Check } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

export default function Settings() {
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState("pro");

  return (
    <div className="h-full overflow-y-auto bg-slate-950">
      <div className="max-w-4xl mx-auto p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-500 to-gray-600 flex items-center justify-center">
              <SettingsIcon className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">Settings</h2>
          </div>
          <p className="text-slate-400">Manage your account and preferences</p>
        </motion.div>

        <div className="space-y-6">
          {/* Profile Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
          >
            <div className="flex items-center gap-3 mb-6">
              <User className="w-5 h-5 text-slate-400" />
              <h3 className="font-semibold text-white">Profile</h3>
            </div>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-2xl font-bold text-white">
                A
              </div>
              <div>
                <h4 className="font-medium text-white">Alex Johnson</h4>
                <p className="text-sm text-slate-400">alex@company.com</p>
              </div>
              <Button className="ml-auto px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl">
                Edit Profile
              </Button>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-slate-400 mb-2">Full Name</label>
                <Input
                  defaultValue="Alex Johnson"
                  className="bg-slate-800 border-slate-700 text-white focus:border-slate-500"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-2">Email</label>
                <Input
                  defaultValue="alex@company.com"
                  className="bg-slate-800 border-slate-700 text-white focus:border-slate-500"
                />
              </div>
            </div>
          </motion.div>

          {/* Appearance */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
          >
            <div className="flex items-center gap-3 mb-6">
              <Palette className="w-5 h-5 text-slate-400" />
              <h3 className="font-semibold text-white">Appearance</h3>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-white">Dark Mode</p>
                <p className="text-sm text-slate-400">Use dark theme across the app</p>
              </div>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`w-12 h-6 rounded-full transition-all ${darkMode ? "bg-violet-500" : "bg-slate-700"}`}
              >
                <motion.div
                  animate={{ x: darkMode ? 24 : 2 }}
                  className="w-5 h-5 rounded-full bg-white shadow-lg"
                />
              </button>
            </div>
          </motion.div>

          {/* Notifications */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
          >
            <div className="flex items-center gap-3 mb-6">
              <Bell className="w-5 h-5 text-slate-400" />
              <h3 className="font-semibold text-white">Notifications</h3>
            </div>
            <div className="space-y-4">
              {[
                { label: "Push Notifications", description: "Receive push notifications" },
                { label: "Email Notifications", description: "Receive email updates" },
                { label: "Weekly Reports", description: "Get weekly usage reports" },
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-white">{item.label}</p>
                    <p className="text-sm text-slate-400">{item.description}</p>
                  </div>
                  <button
                    className={`w-12 h-6 rounded-full transition-all ${notifications ? "bg-violet-500" : "bg-slate-700"}`}
                    onClick={() => setNotifications(!notifications)}
                  >
                    <motion.div
                      animate={{ x: notifications ? 24 : 2 }}
                      className="w-5 h-5 rounded-full bg-white shadow-lg"
                    />
                  </button>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Subscription */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
          >
            <div className="flex items-center gap-3 mb-6">
              <CreditCard className="w-5 h-5 text-slate-400" />
              <h3 className="font-semibold text-white">Subscription</h3>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              {[
                { id: "free", name: "Free", price: "$0", features: ["Limited AI", "Basic features"] },
                { id: "pro", name: "Pro", price: "$19", features: ["Unlimited chat", "HD images", "Priority support"] },
                { id: "business", name: "Business", price: "$49", features: ["Team features", "Analytics", "API access"] },
              ].map((plan) => (
                <button
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id)}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    selectedPlan === plan.id
                      ? "border-violet-500 bg-violet-500/10"
                      : "border-slate-700 bg-slate-800 hover:border-slate-600"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-white">{plan.name}</span>
                    {selectedPlan === plan.id && <Check className="w-4 h-4 text-violet-400" />}
                  </div>
                  <p className="text-2xl font-bold text-white mb-2">{plan.price}<span className="text-sm font-normal text-slate-400">/mo</span></p>
                  <ul className="space-y-1">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="text-xs text-slate-400 flex items-center gap-1">
                        <Check className="w-3 h-3 text-emerald-400" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </button>
              ))}
            </div>
          </motion.div>

          {/* Security */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
          >
            <div className="flex items-center gap-3 mb-6">
              <Shield className="w-5 h-5 text-slate-400" />
              <h3 className="font-semibold text-white">Security</h3>
            </div>
            <div className="space-y-3">
              {[
                { label: "Change Password", action: "Update" },
                { label: "Two-Factor Authentication", action: "Enable" },
                { label: "Active Sessions", action: "Manage" },
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-xl bg-slate-800">
                  <span className="text-white">{item.label}</span>
                  <Button className="px-3 py-1 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm">
                    {item.action}
                  </Button>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Logout */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Button className="w-full py-3 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded-xl border border-red-500/50">
              <LogOut className="w-5 h-5 mr-2" />
              Sign Out
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}