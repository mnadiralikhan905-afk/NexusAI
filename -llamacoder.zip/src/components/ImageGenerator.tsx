import { useState } from "react";
import { motion } from "framer-motion";
import { Image as ImageIcon, Wand2, Download, RefreshCw, Sparkles, Palette, Layers, Maximize } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";

const stylePresets = [
  { id: "realistic", label: "Realistic", icon: "📷" },
  { id: "anime", label: "Anime", icon: "🎨" },
  { id: "3d", label: "3D Render", icon: "🎮" },
  { id: "logo", label: "Logo", icon: "✨" },
  { id: "abstract", label: "Abstract", icon: "🎭" },
  { id: "portrait", label: "Portrait", icon: "👤" },
];

const samplePrompts = [
  "A futuristic cityscape at sunset with flying cars",
  "A mystical forest with glowing mushrooms",
  "A professional logo for a tech startup",
  "An astronaut floating in space with Earth in background",
];

export default function ImageGenerator() {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [selectedStyle, setSelectedStyle] = useState("realistic");
  const [aspectRatio, setAspectRatio] = useState("1:1");

  const handleGenerate = () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    
    // Simulate image generation
    setTimeout(() => {
      setGeneratedImages([
        "generated-1",
        "generated-2",
        "generated-3",
        "generated-4",
      ]);
      setIsGenerating(false);
    }, 3000);
  };

  return (
    <div className="h-full overflow-y-auto bg-slate-950">
      <div className="max-w-6xl mx-auto p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center">
              <ImageIcon className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">AI Image Generator</h2>
          </div>
          <p className="text-slate-400">Create stunning images with AI - from realistic photos to artistic designs</p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Left Panel - Controls */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Prompt Input */}
            <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800">
              <label className="block text-sm font-medium text-slate-300 mb-3">
                Describe your image
              </label>
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="A beautiful sunset over mountains with vibrant colors..."
                className="min-h-24 bg-slate-800 border-slate-700 text-white placeholder-slate-500 focus:border-pink-500 resize-none"
              />
              
              {/* Quick Prompts */}
              <div className="mt-3">
                <p className="text-xs text-slate-500 mb-2">Try these:</p>
                <div className="flex flex-wrap gap-2">
                  {samplePrompts.slice(0, 2).map((p, i) => (
                    <button
                      key={i}
                      onClick={() => setPrompt(p)}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-xs text-slate-400"
                    >
                      {p.substring(0, 30)}...
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Style Selection */}
            <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800">
              <label className="block text-sm font-medium text-slate-300 mb-3">
                Style Preset
              </label>
              <div className="grid grid-cols-3 gap-2">
                {stylePresets.map((style) => (
                  <button
                    key={style.id}
                    onClick={() => setSelectedStyle(style.id)}
                    className={`flex items-center gap-2 p-3 rounded-xl transition-all ${
                      selectedStyle === style.id
                        ? "bg-pink-500/20 border border-pink-500/50"
                        : "bg-slate-800 hover:bg-slate-700"
                    }`}
                  >
                    <span>{style.icon}</span>
                    <span className="text-sm text-white">{style.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect Ratio */}
            <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800">
              <label className="block text-sm font-medium text-slate-300 mb-3">
                Aspect Ratio
              </label>
              <div className="flex gap-2">
                {["1:1", "16:9", "9:16", "4:3"].map((ratio) => (
                  <button
                    key={ratio}
                    onClick={() => setAspectRatio(ratio)}
                    className={`flex-1 py-2 rounded-xl transition-all ${
                      aspectRatio === ratio
                        ? "bg-pink-500/20 border border-pink-500/50 text-pink-400"
                        : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                    }`}
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>

            {/* Generate Button */}
            <Button
              onClick={handleGenerate}
              disabled={!prompt.trim() || isGenerating}
              className="w-full py-3 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white rounded-xl disabled:opacity-50 font-medium"
            >
              {isGenerating ? (
                <>
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  >
                    <RefreshCw className="w-5 h-5 mr-2" />
                  </motion.div>
                  Generating...
                </>
              ) : (
                <>
                  <Wand2 className="w-5 h-5 mr-2" />
                  Generate Image
                </>
              )}
            </Button>
          </motion.div>

          {/* Right Panel - Output */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 h-full">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-medium text-white">Generated Images</h3>
                {generatedImages.length > 0 && (
                  <Button className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm">
                    <Download className="w-4 h-4 mr-1" />
                    Download All
                  </Button>
                )}
              </div>

              {generatedImages.length === 0 ? (
                <div className="h-96 flex items-center justify-center border-2 border-dashed border-slate-800 rounded-xl">
                  <div className="text-center">
                    <div className="w-16 h-16 rounded-xl bg-slate-800 flex items-center justify-center mx-auto mb-4">
                      <Sparkles className="w-8 h-8 text-slate-600" />
                    </div>
                    <p className="text-slate-500">Your generated images will appear here</p>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-4">
                  {generatedImages.map((_, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      className="aspect-square rounded-xl bg-gradient-to-br from-pink-500/20 to-rose-500/20 border border-slate-700 flex items-center justify-center group relative overflow-hidden"
                    >
                      <div className="w-full h-full bg-gradient-to-br from-pink-500/30 to-purple-500/30 flex items-center justify-center">
                        <ImageIcon className="w-12 h-12 text-pink-400/50" />
                      </div>
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <Button className="p-2 bg-white/20 hover:bg-white/30 rounded-lg">
                          <Download className="w-5 h-5 text-white" />
                        </Button>
                        <Button className="p-2 bg-white/20 hover:bg-white/30 rounded-lg">
                          <Maximize className="w-5 h-5 text-white" />
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}