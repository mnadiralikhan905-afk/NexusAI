import { useState } from "react";
import { motion } from "framer-motion";
import { Mic, MicOff, Volume2, VolumeX, Settings, Radio } from "lucide-react";
import { Button } from "./ui/button";

const voiceOptions = [
  { id: "nova", name: "Nova", gender: "Female", accent: "American" },
  { id: "echo", name: "Echo", gender: "Male", accent: "American" },
  { id: "shimmer", name: "Shimmer", gender: "Female", accent: "British" },
  { id: "onyx", name: "Onyx", gender: "Male", accent: "British" },
];

const languages = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "es", name: "Spanish", flag: "🇪🇸" },
  { code: "fr", name: "French", flag: "🇫🇷" },
  { code: "de", name: "German", flag: "🇩🇪" },
  { code: "zh", name: "Chinese", flag: "🇨🇳" },
  { code: "ja", name: "Japanese", flag: "🇯🇵" },
  { code: "ar", name: "Arabic", flag: "🇸🇦" },
  { code: "ur", name: "Urdu", flag: "🇵🇰" },
];

export default function VoiceAssistant() {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState("nova");
  const [selectedLanguage, setSelectedLanguage] = useState("en");
  const [transcript, setTranscript] = useState("");

  const toggleListening = () => {
    setIsListening(!isListening);
    if (!isListening) {
      setTimeout(() => {
        setTranscript("Hello, how can I help you today? I'm your AI voice assistant, ready to assist with any task.");
      }, 2000);
    } else {
      setTranscript("");
    }
  };

  return (
    <div className="h-full overflow-y-auto bg-slate-950">
      <div className="max-w-4xl mx-auto p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
              <Radio className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">Voice AI Assistant</h2>
          </div>
          <p className="text-slate-400">Speak naturally and let AI assist you hands-free</p>
        </motion.div>

        {/* Main Voice Interface */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-slate-900 rounded-3xl p-8 border border-slate-800 mb-6"
        >
          {/* Voice Visualizer */}
          <div className="relative flex justify-center mb-8">
            <motion.div
              animate={{
                scale: isListening ? [1, 1.1, 1] : 1,
              }}
              transition={{ duration: 1, repeat: isListening ? Infinity : 0 }}
              className={`w-32 h-32 rounded-full flex items-center justify-center cursor-pointer ${
                isListening 
                  ? "bg-gradient-to-br from-cyan-500 to-blue-600" 
                  : "bg-slate-800 border-2 border-slate-700"
              }`}
              onClick={toggleListening}
            >
              {isListening ? (
                <div className="flex items-center gap-1">
                  {[...Array(4)].map((_, i) => (
                    <motion.div
                      key={i}
                      animate={{ height: [8, 32, 8] }}
                      transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.1 }}
                      className="w-2 bg-white rounded-full"
                    />
                  ))}
                </div>
              ) : (
                <Mic className="w-12 h-12 text-slate-400" />
              )}
            </motion.div>
            
            {isListening && (
              <>
                <motion.div
                  animate={{ scale: [1, 2], opacity: [0.5, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="absolute w-32 h-32 rounded-full border-2 border-cyan-500"
                />
                <motion.div
                  animate={{ scale: [1, 2.5], opacity: [0.3, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity, delay: 0.3 }}
                  className="absolute w-32 h-32 rounded-full border-2 border-cyan-500"
                />
              </>
            )}
          </div>

          {/* Status */}
          <div className="text-center mb-6">
            <p className={`text-lg font-medium ${isListening ? "text-cyan-400" : "text-slate-400"}`}>
              {isListening ? "Listening..." : "Tap to start speaking"}
            </p>
          </div>

          {/* Transcript */}
          {transcript && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-800/50 rounded-xl p-4 mb-6"
            >
              <p className="text-sm text-slate-400 mb-1">Transcript:</p>
              <p className="text-white">{transcript}</p>
            </motion.div>
          )}

          {/* Controls */}
          <div className="flex items-center justify-center gap-4">
            <Button
              onClick={toggleListening}
              className={`px-6 py-3 rounded-xl font-medium ${
                isListening
                  ? "bg-red-500/20 text-red-400 border border-red-500/50 hover:bg-red-500/30"
                  : "bg-gradient-to-r from-cyan-600 to-blue-600 text-white hover:from-cyan-500 hover:to-blue-500"
              }`}
            >
              {isListening ? (
                <>
                  <MicOff className="w-5 h-5 mr-2" />
                  Stop Listening
                </>
              ) : (
                <>
                  <Mic className="w-5 h-5 mr-2" />
                  Start Listening
                </>
              )}
            </Button>
            <Button 
              onClick={() => setIsSpeaking(!isSpeaking)}
              className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl"
            >
              {isSpeaking ? (
                <>
                  <VolumeX className="w-5 h-5 mr-2" />
                  Stop Speaking
                </>
              ) : (
                <>
                  <Volume2 className="w-5 h-5 mr-2" />
                  Read Aloud
                </>
              )}
            </Button>
          </div>
        </motion.div>

        {/* Settings Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Voice Selection */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-white">Voice Selection</h3>
              <Button className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg">
                <Settings className="w-4 h-4 text-slate-400" />
              </Button>
            </div>
            <div className="space-y-2">
              {voiceOptions.map((voice) => (
                <button
                  key={voice.id}
                  onClick={() => setSelectedVoice(voice.id)}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${
                    selectedVoice === voice.id
                      ? "bg-cyan-500/20 border border-cyan-500/50"
                      : "bg-slate-800 hover:bg-slate-700"
                  }`}
                >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white font-bold">
                    {voice.name[0]}
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-white">{voice.name}</p>
                    <p className="text-xs text-slate-400">{voice.gender} • {voice.accent}</p>
                  </div>
                  {selectedVoice === voice.id && (
                    <div className="ml-auto w-2 h-2 rounded-full bg-cyan-400" />
                  )}
                </button>
              ))}
            </div>
          </motion.div>

          {/* Language Selection */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
          >
            <h3 className="font-semibold text-white mb-4">Language</h3>
            <div className="grid grid-cols-2 gap-2">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setSelectedLanguage(lang.code)}
                  className={`flex items-center gap-2 p-3 rounded-xl transition-all ${
                    selectedLanguage === lang.code
                      ? "bg-cyan-500/20 border border-cyan-500/50"
                      : "bg-slate-800 hover:bg-slate-700"
                  }`}
                >
                  <span className="text-lg">{lang.flag}</span>
                  <span className="text-sm text-white">{lang.name}</span>
                </button>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}