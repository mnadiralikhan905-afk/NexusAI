import { motion } from "framer-motion";
import { MessageSquare, Image, Mic, FileText, CheckSquare, BarChart3, Settings, ChevronLeft, ChevronRight, Zap } from "lucide-react";
import { ViewType } from "../App";

interface SidebarProps {
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

const menuItems = [
  { id: "chat", label: "AI Chat", icon: MessageSquare, color: "from-violet-500 to-purple-600" },
  { id: "image", label: "Image Gen", icon: Image, color: "from-pink-500 to-rose-600" },
  { id: "voice", label: "Voice AI", icon: Mic, color: "from-cyan-500 to-blue-600" },
  { id: "document", label: "Documents", icon: FileText, color: "from-amber-500 to-orange-600" },
  { id: "productivity", label: "Productivity", icon: CheckSquare, color: "from-emerald-500 to-green-600" },
  { id: "analytics", label: "Analytics", icon: BarChart3, color: "from-blue-500 to-indigo-600" },
  { id: "settings", label: "Settings", icon: Settings, color: "from-slate-500 to-gray-600" },
] as const;

export default function Sidebar({ currentView, setCurrentView, collapsed, setCollapsed }: SidebarProps) {
  return (
    <motion.aside
      animate={{ width: collapsed ? 80 : 240 }}
      transition={{ duration: 0.3 }}
      className="bg-slate-900 border-r border-slate-800 flex flex-col h-full"
    >
      {/* Logo */}
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center flex-shrink-0">
            <Zap className="w-5 h-5 text-white" />
          </div>
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <h1 className="font-bold text-lg text-white">NexusAI</h1>
              <p className="text-xs text-slate-500">Super Assistant</p>
            </motion.div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const isActive = currentView === item.id;
          return (
            <motion.button
              key={item.id}
              onClick={() => setCurrentView(item.id as ViewType)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all ${
                isActive
                  ? `bg-gradient-to-r ${item.color} text-white shadow-lg`
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {!collapsed && (
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="font-medium"
                >
                  {item.label}
                </motion.span>
              )}
            </motion.button>
          );
        })}
      </nav>

      {/* Collapse Button */}
      <div className="p-3 border-t border-slate-800">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 transition-colors"
        >
          {collapsed ? (
            <ChevronRight className="w-5 h-5" />
          ) : (
            <>
              <ChevronLeft className="w-5 h-5" />
              <span className="text-sm">Collapse</span>
            </>
          )}
        </button>
      </div>
    </motion.aside>
  );
}