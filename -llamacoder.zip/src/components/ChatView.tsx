import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Paperclip, Mic, Bot, User, Sparkles, Copy, ThumbsUp, ThumbsDown, RotateCcw } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

const initialMessages: Message[] = [
  {
    id: 1,
    role: "assistant",
    content: "Hello! I'm your AI Super Assistant. I can help you with:\n\n• **Conversations** - Ask me anything\n• **Code** - Write, debug, and explain code\n• **Research** - Analyze and summarize information\n• **Writing** - Create content, emails, and documents\n• **Planning** - Organize tasks and schedules\n\nHow can I assist you today?",
    timestamp: new Date(),
  },
];

const suggestedPrompts = [
  "Write a professional email to my team",
  "Explain quantum computing simply",
  "Help me debug my React code",
  "Create a business plan outline",
];

export default function ChatView() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: Date.now() + 1,
        role: "assistant",
        content: generateAIResponse(input),
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const generateAIResponse = (query: string): string => {
    const responses: Record<string, string> = {
      email: "I'd be happy to help you write a professional email. Here's a template:\n\n**Subject:** [Clear Subject Line]\n\nDear [Recipient],\n\nI hope this message finds you well. I'm writing to [purpose].\n\n[Main content - be specific and concise]\n\nPlease let me know if you have any questions or need further clarification.\n\nBest regards,\n[Your Name]",
      code: "Here's an example of clean, well-structured code:\n\n```javascript\nfunction calculateTotal(items) {\n  return items.reduce((sum, item) => {\n    return sum + (item.price * item.quantity);\n  }, 0);\n}\n```\n\nThis function uses the `reduce` method to calculate the total price efficiently.",
      default: "That's a great question! Let me help you with that.\n\nBased on your query, here are some key points to consider:\n\n1. **Understanding the context** - It's important to analyze the situation thoroughly\n2. **Breaking it down** - Complex problems become manageable when divided into smaller parts\n3. **Taking action** - Implement solutions step by step\n\nWould you like me to elaborate on any of these points?",
    };

    if (query.toLowerCase().includes("email")) return responses.email;
    if (query.toLowerCase().includes("code")) return responses.code;
    return responses.default;
  };

  return (
    <div className="h-full flex flex-col bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-800 p-4 bg-slate-900">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-semibold text-white">AI Chat Assistant</h2>
              <p className="text-xs text-slate-500">Always ready to help</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button className="px-3 py-1.5 bg-violet-500/20 text-violet-400 hover:bg-violet-500/30 rounded-lg text-sm">
              <Sparkles className="w-4 h-4 mr-1" />
              New Chat
            </Button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              {message.role === "assistant" && (
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}
              <div className={`max-w-2xl ${message.role === "user" ? "order-first" : ""}`}>
                <div
                  className={`p-4 rounded-2xl ${
                    message.role === "user"
                      ? "bg-violet-500 text-white"
                      : "bg-slate-800 text-slate-200"
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
                {message.role === "assistant" && (
                  <div className="flex items-center gap-2 mt-2">
                    <button className="p-1 rounded hover:bg-slate-800 text-slate-500 hover:text-slate-300">
                      <Copy className="w-4 h-4" />
                    </button>
                    <button className="p-1 rounded hover:bg-slate-800 text-slate-500 hover:text-slate-300">
                      <ThumbsUp className="w-4 h-4" />
                    </button>
                    <button className="p-1 rounded hover:bg-slate-800 text-slate-500 hover:text-slate-300">
                      <ThumbsDown className="w-4 h-4" />
                    </button>
                    <button className="p-1 rounded hover:bg-slate-800 text-slate-500 hover:text-slate-300">
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
              {message.role === "user" && (
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-white" />
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>

        {isTyping && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex gap-3"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-slate-800 p-4 rounded-2xl">
              <div className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    animate={{ y: [0, -5, 0] }}
                    transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.1 }}
                    className="w-2 h-2 rounded-full bg-violet-400"
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts */}
      {messages.length === 1 && (
        <div className="px-4 pb-2">
          <p className="text-xs text-slate-500 mb-2">Suggested prompts:</p>
          <div className="flex flex-wrap gap-2">
            {suggestedPrompts.map((prompt, index) => (
              <button
                key={index}
                onClick={() => setInput(prompt)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm text-slate-300 transition-colors"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="border-t border-slate-800 p-4 bg-slate-900">
        <div className="flex items-end gap-2">
          <Button className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg">
            <Paperclip className="w-5 h-5 text-slate-400" />
          </Button>
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
            placeholder="Type your message..."
            className="flex-1 min-h-10 max-h-32 bg-slate-800 border-slate-700 text-white placeholder-slate-500 focus:border-violet-500 resize-none"
          />
          <Button className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg">
            <Mic className="w-5 h-5 text-slate-400" />
          </Button>
          <Button
            onClick={handleSend}
            disabled={!input.trim()}
            className="px-4 py-2 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white rounded-lg disabled:opacity-50"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}