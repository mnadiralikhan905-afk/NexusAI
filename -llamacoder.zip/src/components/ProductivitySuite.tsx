import { useState } from "react";
import { motion } from "framer-motion";
import { CheckSquare, FileText, Mail, Calendar, Bell, Plus, Check, Clock, Users, Star } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

const initialTasks = [
  { id: 1, title: "Review Q4 marketing report", priority: "high", due: "Today", completed: false },
  { id: 2, title: "Prepare presentation slides", priority: "medium", due: "Tomorrow", completed: false },
  { id: 3, title: "Schedule team meeting", priority: "low", due: "This week", completed: true },
  { id: 4, title: "Update project documentation", priority: "medium", due: "Next week", completed: false },
];

const initialNotes = [
  { id: 1, title: "Meeting Notes - Product Review", date: "Jan 15, 2024", preview: "Discussed new feature roadmap and Q1 priorities..." },
  { id: 2, title: "Ideas for Marketing Campaign", date: "Jan 14, 2024", preview: "Brainstorming session for upcoming product launch..." },
];

export default function ProductivitySuite() {
  const [tasks, setTasks] = useState(initialTasks);
  const [notes] = useState(initialNotes);
  const [newTask, setNewTask] = useState("");
  const [activeTab, setActiveTab] = useState<"tasks" | "notes" | "email">("tasks");

  const toggleTask = (id: number) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const addTask = () => {
    if (!newTask.trim()) return;
    setTasks([
      ...tasks,
      { id: Date.now(), title: newTask, priority: "medium", due: "This week", completed: false }
    ]);
    setNewTask("");
  };

  return (
    <div className="h-full overflow-y-auto bg-slate-950">
      <div className="max-w-6xl mx-auto p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 flex items-center justify-center">
              <CheckSquare className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">Productivity Suite</h2>
          </div>
          <p className="text-slate-400">Manage tasks, notes, and emails with AI assistance</p>
        </motion.div>

        {/* Stats Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6"
        >
          {[
            { label: "Tasks Completed", value: "12", icon: Check, color: "from-emerald-500 to-green-600" },
            { label: "Pending Tasks", value: "5", icon: Clock, color: "from-amber-500 to-orange-600" },
            { label: "Notes Created", value: "8", icon: FileText, color: "from-blue-500 to-cyan-600" },
            { label: "Emails Drafted", value: "23", icon: Mail, color: "from-purple-500 to-violet-600" },
          ].map((stat, index) => (
            <div key={index} className="bg-slate-900 rounded-xl p-4 border border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-500">{stat.label}</span>
                <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <stat.icon className="w-4 h-4 text-white" />
                </div>
              </div>
              <p className="text-2xl font-bold text-white">{stat.value}</p>
            </div>
          ))}
        </motion.div>

        {/* Tabs */}
        <div className="flex items-center gap-2 mb-6">
          {[
            { id: "tasks", label: "Tasks", icon: CheckSquare },
            { id: "notes", label: "Notes", icon: FileText },
            { id: "email", label: "Email Assistant", icon: Mail },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all ${
                activeTab === tab.id
                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/50"
                  : "bg-slate-800 text-slate-400 hover:bg-slate-700"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {activeTab === "tasks" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
              >
                {/* Add Task */}
                <div className="flex items-center gap-2 mb-6">
                  <Input
                    value={newTask}
                    onChange={(e) => setNewTask(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addTask()}
                    placeholder="Add a new task..."
                    className="flex-1 bg-slate-800 border-slate-700 text-white placeholder-slate-500 focus:border-emerald-500"
                  />
                  <Button
                    onClick={addTask}
                    className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white rounded-xl"
                  >
                    <Plus className="w-5 h-5" />
                  </Button>
                </div>

                {/* Task List */}
                <div className="space-y-2">
                  {tasks.map((task) => (
                    <div
                      key={task.id}
                      className={`flex items-center gap-3 p-4 rounded-xl transition-all ${
                        task.completed ? "bg-slate-800/50" : "bg-slate-800"
                      }`}
                    >
                      <button
                        onClick={() => toggleTask(task.id)}
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                          task.completed
                            ? "bg-emerald-500 border-emerald-500"
                            : "border-slate-600 hover:border-emerald-500"
                        }`}
                      >
                        {task.completed && <Check className="w-4 h-4 text-white" />}
                      </button>
                      <div className="flex-1">
                        <p className={`font-medium ${task.completed ? "text-slate-500 line-through" : "text-white"}`}>
                          {task.title}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={`text-xs px-2 py-0.5 rounded-full ${
                            task.priority === "high" ? "bg-red-500/20 text-red-400" :
                            task.priority === "medium" ? "bg-amber-500/20 text-amber-400" :
                            "bg-slate-700 text-slate-400"
                          }`}>
                            {task.priority}
                          </span>
                          <span className="text-xs text-slate-500">{task.due}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === "notes" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-semibold text-white">Recent Notes</h3>
                  <Button className="px-4 py-2 bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 rounded-xl">
                    <Plus className="w-4 h-4 mr-2" />
                    New Note
                  </Button>
                </div>
                <div className="space-y-3">
                  {notes.map((note) => (
                    <div
                      key={note.id}
                      className="p-4 rounded-xl bg-slate-800 hover:bg-slate-700 cursor-pointer transition-all"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">{note.title}</h4>
                        <span className="text-xs text-slate-500">{note.date}</span>
                      </div>
                      <p className="text-sm text-slate-400 line-clamp-2">{note.preview}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === "email" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-slate-900 rounded-2xl p-6 border border-slate-800"
              >
                <h3 className="font-semibold text-white mb-4">AI Email Assistant</h3>
                <div className="space-y-4">
                  <Input
                    placeholder="Email subject..."
                    className="bg-slate-800 border-slate-700 text-white placeholder-slate-500 focus:border-emerald-500"
                  />
                  <textarea
                    placeholder="Describe what you want to write or paste content to rewrite..."
                    className="w-full h-32 p-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none resize-none"
                  />
                  <div className="flex items-center gap-2">
                    <Button className="flex-1 py-2 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white rounded-xl">
                      Generate Email
                    </Button>
                    <Button className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl">
                      Rewrite
                    </Button>
                    <Button className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl">
                      Summarize
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Calendar Widget */}
            <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-white">Upcoming</h3>
                <Calendar className="w-5 h-5 text-slate-400" />
              </div>
              <div className="space-y-3">
                {[
                  { title: "Team Standup", time: "9:00 AM", type: "meeting" },
                  { title: "Project Review", time: "2:00 PM", type: "review" },
                  { title: "Client Call", time: "4:30 PM", type: "call" },
                ].map((event, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800">
                    <div className="w-2 h-8 rounded-full bg-emerald-500" />
                    <div>
                      <p className="text-sm font-medium text-white">{event.title}</p>
                      <p className="text-xs text-slate-500">{event.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Reminders */}
            <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-white">Reminders</h3>
                <Bell className="w-5 h-5 text-slate-400" />
              </div>
              <div className="space-y-2">
                {[
                  "Submit expense report",
                  "Reply to Sarah's email",
                  "Review pull request",
                ].map((reminder, index) => (
                  <div key={index} className="flex items-center gap-2 p-2 rounded-lg bg-slate-800">
                    <Bell className="w-4 h-4 text-amber-400" />
                    <span className="text-sm text-slate-300">{reminder}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}